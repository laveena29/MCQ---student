import React, { useEffect, useState } from "react";
import { Container, Card, Button, Navbar, Nav, Dropdown } from "react-bootstrap";
import axios from "axios";
import { useNavigate, Link} from "react-router-dom";
import { Pie, Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(ArcElement, BarElement, CategoryScale, LinearScale, Tooltip, Legend);
import "./Dashboard.css"; // Import the same styling from the dashboard

function QuizHistory() {
  const [quizHistory, setQuizHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:5000/quiz-history", { withCredentials: true })
      .then((res) => {
        setUser(res.data.user);       // Set user info
        setQuizHistory(res.data.quizzes);  // Set quiz history
        setLoading(false);
      })
      .catch(() => {
        console.error("Failed to load quiz history.");
        setLoading(false);
      });
  }, []);
  

  const handleLogout = async () => {
    try {
      await axios.post("http://localhost:5000/api/logout", {}, { withCredentials: true });
      navigate("/login");
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  const getAccuracyChartData = (quiz) => {
    return {
      labels: ["Correct", "Incorrect"],
      datasets: [
        {
          data: [quiz.correctAnswers, quiz.incorrectAnswers],
          backgroundColor: ["#4CAF50", "#FF5722"],
        },
      ],
    };
  };

  const getChapterDifficultyChartData = (quiz) => {
    const chapterData = quiz.chapters.reduce((acc, entry) => {
      const key = `${entry.chapter} (${entry.difficulty})`;
      if (!acc[key]) {
        acc[key] = { correct: 0, incorrect: 0 };
      }
      acc[key].correct += entry.correct;
      acc[key].incorrect += entry.incorrect;
      return acc;
    }, {});
  
    const labels = Object.keys(chapterData);
    const correctData = labels.map((key) => chapterData[key].correct);
    const incorrectData = labels.map((key) => chapterData[key].incorrect);
  
    return {
      labels,
      datasets: [
        {
          label: "Correct",
          data: correctData,
          backgroundColor: "#4CAF50",
        },
        {
          label: "Incorrect",
          data: incorrectData,
          backgroundColor: "#FF5722",
        },
      ],
    };
  };

  return (
    <div className="quizhistory-container">
      {/* Navbar */}
      <Navbar bg="white" expand="lg" className="mb-4 shadow-sm">
        <Container>
          <Navbar.Brand href="/dashboard">
            <img src="/logo.png"  width="30" height="30" className="d-inline-block align-top" />
            {" "}Zenius
          </Navbar.Brand>
          <Navbar.Toggle />
          <Navbar.Collapse className="justify-content-end">
            <Nav>
              <Nav.Link as={Link} to="/dashboard" className="nav-link-purple">Dashboard</Nav.Link>
              <Nav.Link as={Link} to="/quizzes" className="nav-link-purple">Available Quizzes</Nav.Link>
              <Nav.Link as={Link} to="/quiz-history" className="nav-link-purple">Quiz History</Nav.Link>
              <Nav.Link href="#" className="nav-link-purple"><i className="bi bi-bell"></i></Nav.Link>
              <Dropdown align="end">
                <Dropdown.Toggle variant="light" id="dropdown-basic" className="user-dropdown">
                  {user?.name || "User"}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item href="#">Profile</Dropdown.Item>
                  <Dropdown.Item href="#">Settings</Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Main content */}
      <Container className="main-content">
        <h2 className="mb-4">📜 Quiz History</h2>
        {loading ? (
          <div>Loading...</div>
        ) : quizHistory.length === 0 ? (
          <p>No quizzes attempted yet.</p>
        ) : (
          <div className="quiz-history-list">
            {quizHistory.map((quiz) => (
              <Card className="quiz-history-card-horizontal mb-4" key={quiz.quiz_id}>
                <Card.Body className="d-flex flex-row justify-content-between align-items-center flex-wrap">
                  <div className="quiz-info-section me-4">
                    <h5 className="quiz-history-title">📘 {quiz.remarks}</h5>
                    <p>Score: {quiz.score}</p>
                    <p>Accuracy: {quiz.accuracy}%</p>
                    <p>Time Taken: {quiz.timeTaken} minutes</p>
                    <p>Date: {new Date(quiz.timestamp).toLocaleString()}</p>
                    <Button size="sm" as={Link} to={`/quiz/${quiz.quiz_id}`}>Retake</Button>
                  </div>
                  <div className="quiz-chart-section d-flex flex-row flex-wrap gap-4">
                    <div className="chart-box">
                      <div className="chart-title">Accuracy Breakdown</div>
                      <Pie data={getAccuracyChartData(quiz)} />
                    </div>
                    <div className="chart-box">
                      <div className="chart-title">Chapter & Difficulty Breakdown</div>
                      <Bar data={getChapterDifficultyChartData(quiz)} />
                    </div>
                  </div>
                </Card.Body>
              </Card>
            ))}
          </div>
        )}
      </Container>
    </div>
  );
}

export default QuizHistory;
