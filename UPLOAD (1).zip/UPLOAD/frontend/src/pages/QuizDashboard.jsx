import React, { useState, useEffect } from "react";
import { Container, Card, Button, Spinner, Alert, Navbar, Nav, Dropdown } from "react-bootstrap";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "./Dashboard.css"; // Reuse the same CSS as the user dashboard

function AvailableQuizzesPage() {
  const navigate = useNavigate();

  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [user, setUser] = useState(null);

  useEffect(() => {
    axios
      .get("/api/user/quizzes", { withCredentials: true })
      .then((res) => {
        setQuizzes(res.data.quizzes);
        setUser(res.data.user);       
        setLoading(false);
      })
      .catch(() => {
        setError("Failed to load quizzes.");
        setLoading(false);
      });
  }, []);  

  const handleStartQuiz = (quizId) => {
    navigate(`/quiz/${quizId}`);
  };

  const handleLogout = async () => {
    try {
      await axios.post("http://localhost:5000/api/logout", {}, { withCredentials: true });
      navigate("/login");
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  return (
    <div className="dashboard-container">
      {/* Navigation Bar */}
      <Navbar bg="white" expand="lg" className="mb-4 shadow-sm">
        <Container>
          <Navbar.Brand href="/dashboard">
            <img src="/logo.png"  width="30" height="30" className="d-inline-block align-top" />
            {" "}Zenius
          </Navbar.Brand>
          <Navbar.Toggle />
          <Navbar.Collapse className="justify-content-end">
            <Nav>
              <Nav.Link as={Link} to="/dashboard" className="nav-link-purple">Dashboard</Nav.Link>
              <Nav.Link as={Link} to="/quizzes" className="nav-link-purple">Available Quizzes</Nav.Link>
              <Nav.Link as={Link} to="/quiz-history" className="nav-link-purple">Quiz History</Nav.Link>
              <Nav.Link href="#" className="nav-link-purple"><i className="bi bi-bell"></i></Nav.Link>
              <Dropdown align="end">
                <Dropdown.Toggle variant="light" id="dropdown-basic" className="user-dropdown">
                  {user?.name}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item href="#">Profile</Dropdown.Item>
                  <Dropdown.Item href="#">Settings</Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Main Content */}
      <Container className="main-content">
        <h3 className="section-title mb-4">📚 Your Available Quizzes</h3>

        {loading ? (
          <div className="text-center">
            <Spinner animation="border" />
          </div>
        ) : error ? (
          <Alert variant="danger">{error}</Alert>
        ) : quizzes.length === 0 ? (
          <Alert variant="info">You don't have any quizzes available yet.</Alert>
        ) : (
          <div className="row justify-content-center">
            {quizzes.map((quiz) => (
              <div className="col-md-8" key={quiz.id}> {/* <= Control width */}
                <Card className="mb-3 subject-card">
                  <Card.Body>
                    <Card.Title className="subject-title">
                      {quiz.remarks || "Untitled Quiz"}
                    </Card.Title>
                    <Card.Text className="subject-progress">
                      {quiz.description || "No description provided."}
                    </Card.Text>
                    <Button
                      onClick={() => handleStartQuiz(quiz.id)}
                      variant="primary"
                      className="subject-button"
                    >
                      Start Quiz
                    </Button>
                  </Card.Body>
                </Card>
              </div>
            ))}
          </div>
        )}
      </Container>
    </div>
  );
}

export default AvailableQuizzesPage;
