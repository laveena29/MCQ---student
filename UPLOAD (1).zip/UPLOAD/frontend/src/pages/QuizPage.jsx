import React, { useState, useEffect } from "react";
import { Container, Card, Button, Form, Spinner, Alert } from "react-bootstrap";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import "./Dashboard.css";

function QuizPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [timeLeft, setTimeLeft] = useState(600);

  useEffect(() => {
    axios
      .get(`/api/quiz/${id}`)
      .then((res) => {
        setQuestions(res.data.questions);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setError("Failed to load quiz. Please try again.");
        setLoading(false);
      });
  }, [id]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit(); // Auto-submit when time is up
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleOptionChange = (qId, option) => {
    setAnswers((prevAnswers) => ({ ...prevAnswers, [qId]: option }));
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleSubmit = () => {
    if (submitting) return;

    const allAnswered = Object.keys(answers).length === questions.length;
    if (!allAnswered) {
      alert("Please answer all questions before submitting.");
      return;
    }

    setSubmitting(true);

    axios
      .post(`/api/quiz/${id}/submit`, { answers })
      .then((res) => {
        alert("Quiz submitted! A new quiz has been generated.");
        console.log("Submission response:", res.data);
        navigate("/quiz-history");
      })
      .catch((err) => {
        console.error("Submission error:", err.response?.data || err.message);
        setError("Failed to submit quiz. Please try again.");
        setSubmitting(false);
      });
  };

  if (loading) {
    return (
      <Container className="text-center mt-5">
        <Spinner animation="border" />
      </Container>
    );
  }

  if (error) {
    return (
      <Container className="mt-4">
        <Alert variant="danger">{error}</Alert>
      </Container>
    );
  }

  const question = questions[currentIndex];

  return (
    <div className="dashboard-container py-5">
      <Container>
        <div className="d-flex flex-column flex-md-row gap-4">
          <Card className="flex-fill progress-card">
            <Card.Body>
              <h5 className="card-title text-center mb-4">
                Question {currentIndex + 1} of {questions.length}
              </h5>
              <p className="fw-bold">{question.question}</p>
              <Form className="mt-3">
                {["a", "b", "c", "d"].map((opt) => (
                  <Form.Check
                    key={opt}
                    type="radio"
                    label={question[`option_${opt}`]}
                    name={`q${question.id}`}
                    id={`${question.id}-${opt}`}
                    className="mb-2"
                    checked={answers[question.id] === question[`option_${opt}`]}
                    onChange={() => handleOptionChange(question.id, question[`option_${opt}`])}
                  />
                ))}
              </Form>

              <div className="d-flex justify-content-between mt-4">
                <Button variant="secondary" disabled={currentIndex === 0} onClick={handlePrev}>
                  Previous
                </Button>
                {currentIndex < questions.length - 1 ? (
                  <Button variant="primary" onClick={handleNext}>
                    Next
                  </Button>
                ) : (
                  <Button variant="success" onClick={handleSubmit} disabled={submitting}>
                    {submitting ? "Submitting..." : "Submit Quiz"}
                  </Button>
                )}
              </div>
            </Card.Body>
          </Card>

          <Card
            className="progress-card text-center"
            style={{ minWidth: "180px", height: "fit-content", alignSelf: "start" }}
          >
            <Card.Body>
              <h6 className="card-title">Time Left</h6>
              <div
                style={{
                  fontSize: "2rem",
                  fontWeight: "bold",
                  color: timeLeft < 60 ? "red" : "#5e60ce",
                }}
              >
                {formatTime(timeLeft)}
              </div>
            </Card.Body>
          </Card>
        </div>
      </Container>
    </div>
  );
}

export default QuizPage;
